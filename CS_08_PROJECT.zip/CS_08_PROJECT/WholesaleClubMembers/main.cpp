#include "WholesaleClubMembers.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    WholesaleClubMembers w;
    w.show();
    return a.exec();
}
